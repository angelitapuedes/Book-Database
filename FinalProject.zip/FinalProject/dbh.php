<?php

$server = "localhost";
$username = "user";
$password = "test123";
$dbname = "librarydata";


$conn = mysqli_connect($server, $username, $password, $dbname);


?>