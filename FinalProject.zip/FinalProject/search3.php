
<?php
	include 'header.php';
	include('config/db_connect.php');
?>

<h1><center>READERS</center></h1>
<div class="books-container">

<?php
	if(isset($_POST['submit-search'])){
		$search = mysqli_real_escape_string($conn, $_POST['search']);
		$sql = "SELECT * FROM reader WHERE CONCAT(first_name, ' ', last_name) LIKE '%$search%' OR last_name LIKE '%$search%'";
		
		$result = mysqli_query($conn, $sql);
		$queryResult = mysqli_num_rows($result);

		if($queryResult > 0){
			while($row = mysqli_fetch_assoc($result)){
				echo "<div class= 'book-box'>
				<table border = 1 >
						
						<th>RID</th>
						<th>FIRSTNAME</th>
						<th>LASTNAME</th>

					<tr>
					<td>".$row['Rid']."</td>
				    <td>".$row['first_name']."</td>
				    <td>".$row['last_name']."</td>
					


				    </tr>
				</table>

				</div>";

			}

		}else{
			echo " There are no results matching your results";
		}


	}
 




?>
</div>
<li><a href="Home.html">HOME</a></li>
</body>
</html>
