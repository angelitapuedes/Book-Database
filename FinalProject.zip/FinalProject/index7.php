<?php
	include 'header.php';
	include('config/db_connect.php');
?>

<form action = "search3.php" method = "POST">
	<input type="text" name="search" placeholder="Search">
	<button type="submit" name="submit-search">Search</button>
</form>
<h2>Search for Reader with Firstname or Lastname </h2>
<div class="books-container">
	<?php
		$sql = "SELECT * FROM reader";
		$result = mysqli_query($conn, $sql);
		$queryResults = mysqli_num_rows($result);


		if($queryResults > 0){
			while($row = mysqli_fetch_assoc($result)){
				echo "<div class= 'book-box'>
				</div>";
			}
		}


	?>
</div>
<center><li><a href="Home.html">HOME</a><br>Click on the home link to go back to home page</li></center>
</body>
</html>