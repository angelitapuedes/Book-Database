<html>
<style>
div {
  background-image: url('library.jpg');
}
</style>
<body>

<h2>Background Image</h2>

</body>
</html>