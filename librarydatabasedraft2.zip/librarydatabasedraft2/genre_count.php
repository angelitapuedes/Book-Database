<?php 

	include('config/db_connect.php');

	
	

	// check GET request id param
	if(isset($_GET['bid'])){
		
		// escape sql chars
		$bid = mysqli_real_escape_string($conn, $_GET['bid']);

		// make sql
		// make sql
		//$sql = "SELECT * FROM book WHERE bid = $bid";
		
		$sql2 = 'SELECT COUNT(bid) FROM book WHERE bid=$bid';
		$result1 = mysqli_query($conn, $sql2);
		
		echo print_r($result1);


		

	}

?>






<!DOCTYPE html>
<html>
	
	<?php include('templates/header.php'); ?>

	

				<h4 class="center grey-text">Data Book Count for Genre!</h4>

					<div class="container">
						<div class="row">

				
							<p>Book Count Genre is <?php echo print_r($result1); ?></p>

						</div>
					</div>

			

				

	
	<?php include('templates/footer.php'); ?>

</html>